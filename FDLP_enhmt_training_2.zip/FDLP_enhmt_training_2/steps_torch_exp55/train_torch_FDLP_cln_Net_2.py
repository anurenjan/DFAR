#!/usr/bin/python3

# Copyright (C) 2016 D S Pavan Kumar
# dspavankumar [at] gmail [dot] com
##
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
##
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
##
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from pdb import set_trace as bp  # added break point accessor####################
import time
import os
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from data_gen.dataGeneratorCNN_multiAll_LSTM_800X36 import dataGeneratorCNN_multiAll
import numpy
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from NET.DPLSTM_exp32 import Net
torch.cuda.current_device()


if __name__ != '__main__':
    raise ImportError('This script can only be run, and can\'t be imported')

if len(sys.argv) != 6:
    raise TypeError('USAGE: train.py data_cv  data_tr target_tr dnn_dir')


input_tr = sys.argv[1]
target_tr = sys.argv[2]
input_cv = sys.argv[3]
target_cv = sys.argv[4]
exp = sys.argv[5]

print(input_tr)
print(input_cv)
# Learning parameters
learning = {'rate': 0.0001,
            'minEpoch': 100,
            'lrScale': 0.5,
            'batchSize': 32,
            'lrScaleCount': 50,
            'spliceSize': 1,
            'minValError': 0.002}

os.makedirs(exp, exist_ok=True)

trGen = dataGeneratorCNN_multiAll(
    input_tr, target_tr, exp, learning['batchSize'], learning['spliceSize'])
cvGen = dataGeneratorCNN_multiAll(
    input_cv, target_cv, exp, learning['batchSize'], learning['spliceSize'])

##bp()
print('number of tr steps =%d ' % (trGen.numSteps_tr))
trGen.numSteps=(trGen.numSteps_tr//trGen.batchSize)
print('number of cv steps =%d ' % (cvGen.numSteps_cv))
cvGen.numSteps=(cvGen.numSteps_cv//cvGen.batchSize)




numpy.random.seed(512)
print(trGen.x.shape)
print(trGen.outputFeatDim)


trainloader = trGen
testloader = cvGen
print(trainloader.batchSize)
print(testloader.batchSize)



class Train():
    def __init__(self,losscv_previous_1=10.0):
        self.losscv_previous_1 = losscv_previous_1
        self.losscv_previous_2 = 0.0
        self.losscv_current = 0.0
        self.train_loss_lst = []
        self.validation_loss_lst = []

    def fit(self, net, trGen, cvGen, criterion, optimizer, epoch, totalepoch):
        net.train()
        print('epoch = %d/%d' % (epoch+1, totalepoch))
        running_loss_tr = 0.0
        correct_tr = 0.0
        total_tr = 0.0
        for i, data in enumerate(trGen, 0):
            inputs, labels = data
            # labels=labels.astype(numpy.int64)
            labels = torch.from_numpy(labels)
            labels = labels.cuda().float()
            inputs = Variable(torch.from_numpy(inputs))
            optimizer.zero_grad()
            outputs = net(inputs.cuda().float())
            loss_env = criterion(outputs[:,:,0:64], labels[:,:,0:64])
            loss_crr = criterion(outputs[:,:,64:128], labels[:,:,64:128])
            #bp()
            loss = 0.1*loss_env + 0.9*loss_crr
            loss.backward()
            optimizer.step()
            running_loss_tr += loss.item()

            if i % trGen.numSteps == (trGen.numSteps - 1):

                #          print ('[%d,%5d] loss_tr: %.7f' % (epoch+1,i+1,running_loss_tr/trGen.numSteps))
                print('TRAIN ==> [%d,%5d] LOSS: %.7f ' %
                      (epoch+1, i+1, running_loss_tr))
                self.train_loss_lst.append(running_loss_tr)
                running_loss_tr = 0.0
                ##bp()
                break
#        print ('Finished Training')
# cross validation step

        correct_cv = 0.0
        total_cv = 0.0
        net.eval()
        running_loss_cv = 0.0
        for j, data in enumerate(cvGen, 0):
            images, label = data
            ##bp()
            #print('cv,', i)

            # label=label.astype(numpy.int64)
            label = torch.from_numpy(label)
            label = label.float()
            label = label.cuda()
            images = Variable(torch.from_numpy(images))
            output = net(images.cuda().float())
            loss_env = criterion(output[:,:,0:64], label[:,:,0:64])
            loss_crr = criterion(output[:,:,64:128], label[:,:,64:128])
            #bp()
            loss_cv = 0.1*loss_env + 0.9*loss_crr            
            running_loss_cv += loss_cv.item()
     
            if j % (cvGen.numSteps) == ((cvGen.numSteps) - 1):
                #           
                self.losscv_current = running_loss_cv
                print('VALID ==> [%d,%5d] LOSS_CV: %.7f ' %
                      (epoch+1, j+1, running_loss_cv))
                self.validation_loss_lst.append(running_loss_cv)
                running_loss_cv = 0.0

                self.losscv_previous_2 = self.losscv_previous_1
                self.losscv_previous_1 = self.losscv_current
                print('loss previous[-1] =%f ' % (self.losscv_previous_1))
                print('loss previous[-2] =%f ' % (self.losscv_previous_2))
                torch.save(net.state_dict(), exp + '/dnn_nnet_64_' + str(epoch) + '.model')
                print('Saved model')
                break
                # else:
                # break
        sys.stdout.flush()
        sys.stderr.flush()

    def plot_figure(self,exp):
        plt.figure(1)
        plt.plot(self.train_loss_lst)
        ##bp()
        plt.savefig(os.path.join(exp,'loss_train.png'))

        plt.figure(2)
        plt.plot(self.validation_loss_lst)
        plt.savefig(os.path.join(exp,'loss_validation.png'))


net = Net()
net = net.cuda()
print(net)
print(sum(p.numel() for p in net.parameters()))
train1 = Train()
criterion = nn.MSELoss()
#optimizer =optim.SGD(net.parameters(),lr=learning['rate'],weight_decay=0,momentum=0.5,nesterov=True)
optimizer = optim.Adam(net.parameters(), lr=learning['rate'], amsgrad=True)

#path_of_model = '/data2/multiChannel/ANURENJAN/VOICES/ENV_estimation/Matlab_env_training/exp/torch_ENV_CLN_Net_CNN_2Layer_LSTM_arfit_after-revamp/dnn_nnet_64.model'
#net.load_state_dict(torch.load(path_of_model))

#bp()

# train minimum of 4 epoch. Save the model only if it improves
for epoch in range(learning['minEpoch']-1):
    if(epoch >= 1):
        net.load_state_dict(torch.load(exp + '/dnn_nnet_64_' + str(epoch-1) + '.model'))
    t0 = time.time()
    abc = train1.fit(net, trGen, cvGen, criterion, optimizer, epoch, learning['minEpoch'])
    train1.plot_figure(exp)
    print('{} seconds'.format(time.time() - t0))

#bp()

# load the best model, and retrain with the same learning rate only if the model improves
valErrorDiff = learning['minValError']
while valErrorDiff >= learning['minValError']:
    print(valErrorDiff)
    net = Net()
    net = net.cuda()
    net.load_state_dict(torch.load(exp + '/dnn_nnet_64_' + str(epoch) + '.model'))
    t0 = time.time()
    epoch = epoch + 1
    abd = train1.fit(net, trGen, cvGen, criterion, optimizer, epoch, epoch + 1)
    valErrorDiff = train1.losscv_previous_2 - train1.losscv_previous_1
    train1.plot_figure(exp)
    print('{} seconds'.format(time.time() - t0))

#bp()
# load the previous best model, lower the learning rate and run the model untill the value of loss is same for two models
while learning['rate'] > 0.000000001:
    learning['rate'] *= learning['lrScale']
    print('Learning rate: %f' % learning['rate'])
    learning['lrScaleCount'] -= 1
    net.load_state_dict(torch.load(exp + '/dnn_nnet_64_' + str(epoch) + '.model'))
   #optimizer =optim.SGD(net.parameters(),lr=learning['rate'],weight_decay=0,momentum=0.5,nesterov=True)
    optimizer = optim.Adam(net.parameters(), lr=learning['rate'], amsgrad=True)
    t0 = time.time()
    epoch = epoch + 1
    abe = train1.fit(net, trGen, cvGen, criterion, optimizer, epoch, epoch + 1)
    err = train1.losscv_previous_2 - train1.losscv_previous_1
    sys.stdout.flush()
    sys.stderr.flush()
    train1.plot_figure(exp)
    print('{} seconds'.format(time.time() - t0))





