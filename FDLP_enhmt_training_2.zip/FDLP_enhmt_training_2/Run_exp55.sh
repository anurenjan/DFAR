#!/bin/bash
set -e
stage=1
nj=10
. ./cmd.sh
. ./path.sh


## Configurable directories
fbankdir="data-Input_training_data"
traindir="REVERB_tr_cut/SimData_tr_for_1ch_A_tr90"
devdir="REVERB_tr_cut/SimData_tr_for_1ch_A_cv10"
tgt="cleanTrain"
input_tr=${fbankdir}/${traindir}
input_cv=${fbankdir}/${devdir}
target_tr=${fbankdir}/${tgt}/cleanTrain_cut_tr90
target_cv=${fbankdir}/${tgt}/cleanTrain_cut_cv10
echo $input_tr
echo $input_cv



exp=exp/torch_FDLP_ENHMT_exp55
mkdir -p $exp

ab=`nvidia-smi --query-gpu=index,memory.used --format=csv`
echo $ab
zero=`echo $ab | awk '{print $5}'`
one=`echo $ab | awk '{print $8}'`
gpu=0
if [ $zero -le  100 ] ;then
gpu=0
elif [ $one -le 100 ]; then
gpu=1
else
echo "GPUs not free, please run again"
exit
fi
echo "using gpu $gpu"


## Train
if [ $stage -le 1 ] ; then

echo "`pwd`"

CUDA_VISIBLE_DEVICES=${gpu}  python steps_torch_exp55/train_torch_FDLP_cln_Net_2.py ${input_tr}  ${target_tr} ${input_cv} ${target_cv} $exp
echo "Training completed"
fi
