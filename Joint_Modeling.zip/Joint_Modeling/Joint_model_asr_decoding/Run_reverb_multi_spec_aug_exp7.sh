#!/bin/bash

#E2E ASR FOR SAMSUNG 150 HRS

. ./path.sh || exit 1;
. ./cmd.sh || exit 1;

# general configuration
backend=pytorch
stage=7        # start from 0 if you need to start from data preparation
stop_stage=7
ngpu=1         # number of gpus ("0" uses cpu, otherwise use gpu)
debugmode=1
dumpdir=dump_FBANK_exp7   # directory to dump full features
N=0            # number of minibatches to be used (mainly for debugging). "0" uses all minibatches.
verbose=0      # verbose option
#resume=/home/rohitk/Workspace/E2E/espnet/egs/chime6/voices_1/exp/train_data_pytorch_train/results/snapshot.ep.26        # Resume the training from snapshot
resume=
foreground_snrs="20:10:15:5:0"
background_snrs="20:10:15:5:0"

# feature configuration
do_delta=false

train_config=conf/train.yaml
lm_config=conf/lm.yaml
decode_config=conf/decode.yaml

# rnnlm related
use_wordlm=true     # false means to train/use a character LM
lm_vocabsize=65000  # effective only for word LMs
lm_resume=          # specify a snapshot file to resume LM training
lmtag=              # tag for managing LMs

# decoding parameter
recog_model=model.loss.best # set a model to be used for decoding: 'model.acc.best' or 'model.loss.best'

# data #data will be mentioned in the wac.scp
data_corpus=

# exp tag

tag="REVERB_FBANK_CLN_WSJ_BR_NO_SHUFFLE_WITH_SP_PT3_MULTI_exp7" # tag for managing experiments.

. utils/parse_options.sh || exit 1;

# Set bash to 'debug' mode, it will exit on :
# -e 'error', -u 'undefined variable', -o ... 'error in pipeline', -x 'print commands',
set -e
set -u
set -o pipefail

lm_url=www.openslr.org/resources/11
train_data=train_clean_100_reverb
eval_data=Evaluation_Data_wpe

# This STAGE IS FOR LM IN KALDI, BUT FOR E2E WE DONT NEED THIS SECTION ####################################

if [ ${stage} -le 1 ] && [ ${stop_stage} -ge 1 ]; then
	echo "stage 1 create LM with this data"
	sam_local/download_lm.sh $lm_url data/local/lm
	mkdir -p data/${train_data}/corpus
	cat data/${train_data}/text | cut -f2- -d' ' > data/${train_data}/corpus/allText.txt
	sam_local/lm/train_lm.sh  data/${train_data}/ data/local/lm_new/norm/tmp data/local/lm_new/norm/norm_texts data/local/lm_new
	
	sam_local/prepare_dict.sh --stage 3 --nj 40 --cmd "$train_cmd" \
	   data/local/lm_new data/local/lm_new data/local/dict_nosp

	utils/prepare_lang.sh data/local/dict_nosp \
         "<UNK>" data/local/lang_tmp_nosp data/lang_nosp

	sam_local/format_lms.sh --src-dir data/lang_nosp data/local/lm

	utils/build_const_arpa_lm.sh data/local/lm/lm_tglarge.arpa.gz \
          data/lang_nosp data/lang_nosp_test_tglarge
  	utils/build_const_arpa_lm.sh data/local/lm/lm_fglarge.arpa.gz \
    	  data/lang_nosp data/lang_nosp_test_fglarge
fi

###############################################################################################################

# NOW WE SPECIFY THE TRAINING DATA, AND SPLIT IT IN TRAIN AND DEV

#utils/subset_data_dir_tr_cv.sh data/$train_data data/${train_data}_tr90 data/${train_data}_cv10
#train_set=${train_data}_tr90
#train_dev=${train_data}_cv10
#eval_set=Eval_latest # EVAL DATASET THAT WE MENTION

#train_set_voices=train_clean_100_reverb_wpe
train_set=train_data
train_set_wsj=train_wsj_clean
train_set_rvb=REVERB_tr_cut
dev_real=REVERB_Real_dt
dev_simu=REVERB_dt_simu
dev_multi=REVERB_dt_multi
eval_real=REVERB_Real_et
eval_simu=REVERB_et_simu

################################################################################################################

# NOW WE EXTRACT THE FBANK FEATS OF THE DATA

if [ ${stage} -le 2 ] && [ ${stop_stage} -ge 2 ]; then

 echo "stage 2: Feature Generation"
 fbankdir=fbank_exp7
 
 for x in ${train_set_wsj} ${train_set_rvb}; do 
 
     steps/make_fbank.sh --cmd "$train_cmd" --nj 25 --write_utt2num_frames true \
          data-fbank_exp7/${x} exp/make_fbank/${x} ${fbankdir}
     utils/fix_data_dir.sh data-fbank_exp7/${x}
 done
 
 #exit
 echo "combine training data of reverb and wsj clean training data"
 
 utils/combine_data.sh --extra-files 'utt2num_frames' data-fbank_exp7/${train_set} data-fbank_exp7/${train_set_wsj} data-fbank_exp7/${train_set_rvb}
 
 #./shuffle_wsj_rvb_data_2.sh
 
 compute-cmvn-stats scp:data-fbank_exp7/${train_set}/feats.scp data-fbank_exp7/${train_set}/cmvn.ark
 
 #exit
 
 for x in ${dev_real} ${dev_simu} ${eval_real} ${eval_simu}; do 
 
     steps/make_fbank.sh --cmd "$train_cmd" --nj 25 --write_utt2num_frames true \
          data-fbank_exp7/${x} exp/make_fbank/${x} ${fbankdir}
     utils/fix_data_dir.sh data-fbank_exp7/${x}
 done
 
 utils/combine_data.sh --extra-files 'utt2num_frames' data-fbank_exp7/${dev_multi} data-fbank_exp7/${dev_simu} data-fbank_exp7/${dev_real}
 
 # AFTER EXTRACTING FBANK COPY THE TRAIN, DEV AND EVAL IN SOME FOLDER DATA_FBANK OR SOMETHING LIKE THIS FOR CONVENIENCE
 # HENCE EXTRACT CMVN FOR THE TRAINING DATA
 # WE ARE EXTRACTING GLOBAL CMVN
 
fi
 
echo "Stage 2 Completed"

#exit
###################################################################################################################

# CREATE THE DUMP FOLDER WHERE WE LATER ON PUT FEATS AND DATA.JSON

feat_tr_dir=${dumpdir}/${train_set}/delta${do_delta}; mkdir -p ${feat_tr_dir}
feat_dt_real_dir=${dumpdir}/${dev_real}/delta${do_delta}; mkdir -p ${feat_dt_real_dir}
feat_dt_simu_dir=${dumpdir}/${dev_simu}/delta${do_delta}; mkdir -p ${feat_dt_simu_dir}
feat_dt_multi_dir=${dumpdir}/${dev_multi}/delta${do_delta}; mkdir -p ${feat_dt_multi_dir}
feat_et_real_dir=${dumpdir}/${eval_real}/delta${do_delta}; mkdir -p ${feat_et_real_dir}
feat_et_simu_dir=${dumpdir}/${eval_simu}/delta${do_delta}; mkdir -p ${feat_et_simu_dir}

# CREATE THE DICTIONARY FOR DATA TRAINING
#dict=data/lang_1char/${train_set}_units.txt
dict=data/lang_1char/${train_set}_units.txt
echo "dictionary: ${dict}"
nlsyms=data/lang_1char/non_lang_syms.txt

echo "dictionary: ${dict}"
if [ ${stage} -le 3 ] && [ ${stop_stage} -ge 3 ]; then
 ### Task dependent. You have to check non-linguistic symbols used in the corpus.
 echo "stage 3: Dictionary and Json Data Preparation"
 mkdir -p data/lang_1char/
 
 echo "make a non-linguistic symbol list"
 #cut -f 2- data-fbank_exp7/${train_set}/text | tr " " "\n" | sort | uniq | grep "<" > ${nlsyms}
 cat data-fbank_exp7/${train_set}/text| awk -F ' ' '{print $2}' | tr " " "\n" | sort | uniq | grep "<" > ${nlsyms}
 cat ${nlsyms}

 echo "make a dictionary"
 echo "<unk> 1" > ${dict}
 text2token.py -s 1 -n 1 -l ${nlsyms} data-fbank_exp7/${train_set}/text | cut -f 2- -d" " | tr " " "\n" \
 | sort | uniq | grep -v -e '^\s*$' | awk '{print $0 " " NR+1}' >> ${dict}
 wc -l ${dict}
 
echo "Stage 3 Completed"
   
fi



#exit

##########################################################################################################################

# DUMP THE FEATS.SCP IN THE DUMP FOLDER

if [ ${stage} -le 4 ] && [ ${stop_stage} -ge 4 ]; then
    echo "[STAGE 4]: dump features for training..."
    dump.sh --cmd "$train_cmd" --nj 32 --do_delta ${do_delta} data-fbank_exp7/${train_set}/feats.scp data-fbank_exp7/${train_set}/cmvn.ark exp/dump_feats/train ${feat_tr_dir}
    dump.sh --cmd "$train_cmd" --nj 4 --do_delta ${do_delta} data-fbank_exp7/${dev_real}/feats.scp data-fbank_exp7/${train_set}/cmvn.ark exp/dump_feats/dev ${feat_dt_real_dir}
    dump.sh --cmd "$train_cmd" --nj 4 --do_delta ${do_delta} data-fbank_exp7/${dev_simu}/feats.scp data-fbank_exp7/${train_set}/cmvn.ark exp/dump_feats/eval ${feat_dt_simu_dir}
    dump.sh --cmd "$train_cmd" --nj 4 --do_delta ${do_delta} data-fbank_exp7/${dev_multi}/feats.scp data-fbank_exp7/${train_set}/cmvn.ark exp/dump_feats/eval ${feat_dt_multi_dir}
    dump.sh --cmd "$train_cmd" --nj 4 --do_delta ${do_delta} data-fbank_exp7/${eval_real}/feats.scp data-fbank_exp7/${train_set}/cmvn.ark exp/dump_feats/dev ${feat_et_real_dir}
    dump.sh --cmd "$train_cmd" --nj 4 --do_delta ${do_delta} data-fbank_exp7/${eval_simu}/feats.scp data-fbank_exp7/${train_set}/cmvn.ark exp/dump_feats/eval ${feat_et_simu_dir}

echo "Stage 4 completed"

fi

#exit

#############################################################################################################################

# NOW THIS STAGE CREATE THE JSON FILE NEEDED TO TRAIN THE ASR

if [ ${stage} -le 5 ] && [ ${stop_stage} -ge 5 ]; then
    echo "[STAGE 5]: make json files..."
    data2json.sh --feat ${feat_tr_dir}/feats.scp --nlsyms ${nlsyms} data-fbank_exp7/${train_set} ${dict} > ${feat_tr_dir}/data.json
    data2json.sh --feat ${feat_dt_real_dir}/feats.scp --nlsyms ${nlsyms} data-fbank_exp7/${dev_real} ${dict} > ${feat_dt_real_dir}/data.json
    data2json.sh --feat ${feat_dt_simu_dir}/feats.scp --nlsyms ${nlsyms} data-fbank_exp7/${dev_simu} ${dict} > ${feat_dt_simu_dir}/data.json
    data2json.sh --feat ${feat_dt_multi_dir}/feats.scp --nlsyms ${nlsyms} data-fbank_exp7/${dev_multi} ${dict} > ${feat_dt_multi_dir}/data.json
    data2json.sh --feat ${feat_et_real_dir}/feats.scp --nlsyms ${nlsyms} data-fbank_exp7/${eval_real} ${dict} > ${feat_et_real_dir}/data.json
    data2json.sh --feat ${feat_et_simu_dir}/feats.scp --nlsyms ${nlsyms} data-fbank_exp7/${eval_simu} ${dict} > ${feat_et_simu_dir}/data.json

echo "Stage 5 completed"

fi

#exit
###############################################################################################################################

ab=`nvidia-smi --query-gpu=index,memory.used --format=csv`
echo $ab
zero=`echo $ab | awk '{print $5}'`
one=`echo $ab | awk '{print $8}'`
gpu=0
if [ $zero -le  $one ] ;then
gpu=0
else
gpu=1
fi
echo "using gpu ${gpu}"




################################################################################################################################
if [ -z ${tag} ]; then
    expname=${train_set}_${backend}_$(basename ${train_config%.*})
    if ${do_delta}; then
        expname=${expname}_delta
    fi
else
    expname=${train_set}_${backend}_${tag}
fi
expdir=exp/${expname}
mkdir -p ${expdir}

if [ ${stage} -le 6 ] && [ ${stop_stage} -ge 6 ]; then
    echo "[STAGE 6]: Network Training"

    CUDA_VISIBLE_DEVICES=${gpu} ${cuda_cmd} --gpu ${ngpu} ${expdir}/train.log \
        asr_train.py \
        --config ${train_config} \
        --ngpu ${ngpu} \
        --backend ${backend} \
        --outdir ${expdir}/results \
        --tensorboard-dir tensorboard/${expname} \
        --debugmode ${debugmode} \
        --dict ${dict} \
        --debugdir ${expdir} \
        --minibatches ${N} \
        --verbose ${verbose} \
        --resume ${resume} \
        --train-json ${feat_tr_dir}/data.json \
        --valid-json ${feat_dt_multi_dir}/data.json \
        --preprocess-conf conf/specaug.yaml
fi

echo "Stage 6 completed"

#exit

# decoding parameter
recog_model=model.acc.best # set a model to be used for decoding: 'model.acc.best' or 'model.loss.best'



if [ -z ${lmtag} ]; then
    lmtag=$(basename ${lm_config%.*})
    if [ ${use_wordlm} = true ]; then
        lmtag=${lmtag}_word${lm_vocabsize}
    fi
fi

lmexpname=train_rnnlm_${backend}_${lmtag}
lmexpdir=exp/${lmexpname}

###############################################################################################################################################
if [ ${stage} -le 7 ] && [ ${stop_stage} -ge 7 ]; then
    echo "stage 7: Decoding"
    nj=5

    pids=() # initialize pids
    for rtask in ${dev_real} ${dev_simu} ${eval_real} ${eval_simu}; do
    (
        decode_dir=decode_${rtask}_$(basename ${decode_config%.*})
        if [ ${use_wordlm} = true ]; then
            decode_dir=${decode_dir}_wordrnnlm_${lmtag}
        else
            decode_dir=${decode_dir}_rnnlm_${lmtag}
        fi
        if [ ${use_wordlm} = true ]; then
            recog_opts="--word-rnnlm ${lmexpdir}/rnnlm.model.best"
        else
            recog_opts="--rnnlm ${lmexpdir}/rnnlm.model.best"
        fi
        feat_recog_dir=${dumpdir}/${rtask}/delta${do_delta}

        # split data
        splitjson.py --parts ${nj} ${feat_recog_dir}/data.json

        #### use CPU for decoding
        ngpu=0

        ${decode_cmd} JOB=1:${nj} ${expdir}/${decode_dir}/log/decode.JOB.log \
            asr_recog.py \
            --config ${decode_config} \
            --ngpu ${ngpu} \
            --backend ${backend} \
            --debugmode ${debugmode} \
            --recog-json ${feat_recog_dir}/split${nj}utt/data.JOB.json \
            --result-label ${expdir}/${decode_dir}/data.JOB.json \
            --model ${expdir}/results/${recog_model}  \
            ${recog_opts}

        score_sclite.sh --wer true --nlsyms ${nlsyms} ${expdir}/${decode_dir} ${dict}

    ) &
    pids+=($!) # store background pids
    done
    i=0; for pid in "${pids[@]}"; do wait ${pid} || ((++i)); done
    [ ${i} -gt 0 ] && echo "$0: ${i} background jobs are failed." && false

    echo "Report the result"
    decode_part_dir=$(basename ${decode_config%.*})
    if [ ${use_wordlm} = true ]; then
        decode_part_dir=${decode_part_dir}_wordrnnlm_${lmtag}
    else
        decode_part_dir=${decode_part_dir}_rnnlm_${lmtag}
    fi
    local/get_results.sh ${nlsyms} ${dict} ${expdir} ${decode_part_dir}
    echo "Finished"
fi

echo "Stage 7 completed"
