
sdir=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/Joint_Modeling/Joint_model_enhancement/CLSTM_joint_exp7
pwdr=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/Joint_Modeling/Joint_model_asr_decoding/data-fbank_exp7


################### Creating wav.scp for Matlab feature extraction... ##################################

for x in $sdir/* ; do
   echo $x	
   
     tpp=`echo $x | sed "s~${sdir}~${pwdr}~"`		

     echo $tpp
     mkdir -p $tpp
     output_wavfiles=$tpp/wav.scp
     utt2spk=$tpp/utt2spk
     spk2utt=$tpp/spk2utt
     text=$tpp/text 
     rm -f $utt2spk
     rm -f $spk2utt 
     rm -f $text     
     rm -f $output_wavfiles
     #find $x | grep .wav | sort >> $output_wavfiles
     find $x -name "*.wav" | awk '{ file=$1; label=$1; gsub(/.*\//,"",label); gsub(/\..*/,"",label); print label" "file; }' | sort >> $output_wavfiles

    find $x -name "*.wav" | awk '{ file=$1; label=$1; gsub(/.*\//,"",label); gsub(/\..*/,"",label); print label" "label; }' | sort >> $utt2spk
     find $x -name "*.wav" | awk '{ file=$1; label=$1; gsub(/.*\//,"",label); gsub(/\..*/,"",label); print label" "label; }' | sort >> $spk2utt

    cat $x/text | sort > $text



	
done



scp -r /data2/multiChannel/ANURENJAN/REVERB_E2E/WSJ_DATA_MASTER/train_wsj_clean $pwdr
rm -f $pwdr/train_wsj_clean/feats.scp

scp -r /data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/ASR/FDLP_enhmt_ASR_envelope_only_FBANK_trial_2/data-fbank_exp7/REVERB_tr_cut $pwdr
rm -f $pwdr/REVERB_tr_cut/feats.scp



mkdir -p $pwdr/train_data

cat data-fbank_exp7/REVERB_tr_cut/wav.scp data-fbank_exp7/train_wsj_clean/wav.scp| sort > data-fbank_exp7/train_data/wav.scp
cat data-fbank_exp7/REVERB_tr_cut/utt2spk data-fbank_exp7/train_wsj_clean/utt2spk| sort > data-fbank_exp7/train_data/utt2spk
cat data-fbank_exp7/REVERB_tr_cut/utt2spk data-fbank_exp7/train_wsj_clean/utt2spk| sort > data-fbank_exp7/train_data/spk2utt
cat data-fbank_exp7/REVERB_tr_cut/text data-fbank_exp7/train_wsj_clean/text| sort > data-fbank_exp7/train_data/text


