#!/bin/bash
. ./path.sh
fbankdir="Input_raw_data"
name="arFeat"
nj=5;
while read x
do

dirhtk=${fbankdir}/${x}
echo $dirhtk
dirbase=`echo $dirhtk ` #| sed -e 's/_A//g'` 
dataDirbase=`echo "data-${fbankdir}/${x}"` #| sed -e 's/_A//g'`
echo $x
echo "Converting Features to kaldi format"
  # Convert PLPs
  # prepare scpfiles with HTK features (2col kaldi-style)
refdirbase="Input_raw_data/${x}"
echo $refdirbase

htkfeatdir=${dirhtk}
echo "htkfeatdir is ${htkfeatdir}"
find $htkfeatdir -name *.fea | awk '{ file=$1; label=$1; gsub(/.*\//,"",label); gsub(/\..*/,"",label); print label" "file; }' | sort > ${htkfeatdir}.scp

  echo Generated ${htkfeatdir}.scp 
  featdir=${dirbase}.kaldi; mkdir -p $featdir || exit 1;
  data=${dataDirbase}; mkdir -p $data || exit 1;
  refdirdata="${refdirbase}" #changed here from reverb
  echo " refdirdata is $refdirdata"
  utils/copy_data_dir.sh ${refdirdata} ${data}
  rm -rf $data/feats.scp  
  rm -rf $data/cmvn.scp
  #rm $data/skp_map
  #rm $data/utt_map
  cp -r ${refdirdata}/utt2spk ${data} #changed here from reverb
  cp -r ${refdirdata}/text ${data}  #changed here from reverb
  cp -r ${refdirdata}/spk2utt ${data}  #changed here from reverb
  split_scps=""
  for n in `seq 1 $nj`; do  
    split_scps="$split_scps ${htkfeatdir}.$n.scp"
  done
  echo $split_scps
  utils/split_scp.pl ${htkfeatdir}.scp $split_scps || exit 1;
  # import features
  for JOB in `seq 1 $nj` ; do 
    copy-feats --htk-in=true scp:${htkfeatdir}.${JOB}.scp \
     ark,scp:$featdir/logmel_${name}.${JOB}.ark,$featdir/logmel_${name}.${JOB}.scp || exit 1;
   done
  # concatenate the .scp files
  for n in `seq 1 $nj`; do
    cat $featdir/logmel_${name}.${n}.scp | sed -e "s/_${chn} / \/data2\/multiChannel\/ANURENJAN\/SPEECH_ENHANCEMENT\/FDLP_based_enhmt\/REVERB\/Joint_Modeling\/Pre_processing_decoding\//g" || exit 1;
  done > $data/feats.scp
  rm ${htkfeatdir}.*.scp

  #steps/compute_cmvn_stats.sh \
     # /data2/multiChannel/ANURENJAN/REVERB_E2E/ASR/ENV_CLN_FDLP/$data exp/make_${fbankdir}/${x} $featdir || exit 1;
#done
#/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/Joint_Modeling/Pre_processing_decoding

done < dir_list
