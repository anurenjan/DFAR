#!/bin/bash


. ./path.sh || exit 1;
. ./cmd.sh || exit 1;



data_folder="data-Input_raw_data"

dev_real=data-Input_raw_data/REVERB_Real_dt
dev_simu=data-Input_raw_data/REVERB_dt_simu
#dev_multi=REVERB_dt_multi
eval_real=data-Input_raw_data/REVERB_Real_et
eval_simu=data-Input_raw_data/REVERB_et_simu


nlsyms=data/lang_1char/non_lang_syms.txt
dict=data/lang_1char/train_data_units.txt



	for rtask in ${dev_real} ${dev_simu} ${eval_real} ${eval_simu};do
	data2json.sh --feat $rtask/feats.scp --nlsyms ${nlsyms} $rtask ${dict} > $rtask/data.json
	done




