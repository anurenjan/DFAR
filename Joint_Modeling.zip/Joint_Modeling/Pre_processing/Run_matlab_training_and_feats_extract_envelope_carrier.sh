#!/bin/bash
############################## Set The Stage ############################## 
set -e
stage=4
nj=20
############################## Run Cmd.sh and Path.sh ##############################
. ./cmd.sh
. ./path.sh

############################## Set the Directory names ############################## 
sdir=/data2/multiChannel/ANURENJAN/REVERB/WPE_GEV_BF_AUDIO
pwdr=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/Joint_Modeling/Pre_processing/Input_training_data_jt_trial

Scr_cln_dir=/data2/multiChannel/ANURENJAN/REVERB/ENV_estimation/Matlab_RAW_features/Input_training_data_jt_trial/cleanTrain/cleanTrain_cut
pwd_cln_dir=$pwdr/cleanTrain/cleanTrain_cut

hcopybin=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/Joint_Modeling/Pre_processing/data_prep/generate_fdlp_feats_mc.sh
matlab_path=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/Joint_Modeling/Pre_processing/FDLP_QMF_64_band_env_carr
dir_2=Input_training_data_jt_trial


inputfeat_dir="Input_training_data_jt_trial"
inputcleanfeat_dir="Input_training_data_jt_trial"
dir=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/Joint_Modeling/Pre_processing/


subset_dir=data-Input_training_data_jt_trial/REVERB_tr_cut/SimData_tr_for_1ch
subset_cln_dir=data-Input_training_data_jt_trial/cleanTrain/cleanTrain_cut
############################## Make Directories ############################## 

if [ $stage -le 1 ] ; then
echo "Extracting features only for training datas"
bash data_prep/make_feat_dir.sh $sdir $pwdr
echo "############################## Feat Directory is ready ############################## "
fi

#exit


if [ $stage -le 2 ] ; then
echo "creating the clean data repo"
mkdir -p $pwd_cln_dir
cp $Scr_cln_dir/wav.scp $pwd_cln_dir/
fi

#exit


if [ $stage -le 3 ] ; then
echo "Splitting the jobs to generate the features from matlab"
bash data_prep/step1_fdlp_gen.sh $pwdr $hcopybin $matlab_path $nj
fi


#exit


if [ $stage -le 4 ] ; then
echo "Convert to kaldi Reverb data"
bash data_prep/Convert_to_kaldi.sh $inputfeat_dir $dir $dir_2


echo "Convert to kaldi Clean data"
bash data_prep/Convert_to_kaldi_cln_train.sh $inputfeat_dir $dir $dir_2 
fi

#exit

if [ $stage -le 5 ] ; then
echo "Create subset for the training and cross validation"
bash data_prep/subset.sh $subset_dir
bash data_prep/subset_cln.sh $subset_cln_dir
fi

exit

if [ $stage -le 6 ] ; then
########### training the model for cleaning ##################
echo "########### training the model for cleaning ##################"
bash run_REVERB_ENV_CLN_CDNN_large_kernel_1 
fi


