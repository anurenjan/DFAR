#!/usr/bin/python3

# Copyright (C) 2016 D S Pavan Kumar
# dspavankumar [at] gmail [dot] com
##
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
##
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
##
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


from subprocess import Popen, PIPE
import tempfile
import kaldiIO
import pickle
import numpy
import os
from backports import tempfile
from pdb import set_trace as bp  # added break point accessor####################

path='/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/Joint_Modeling/Pre_processing/data-Input_training_data_jt_trial/REVERB_tr_cut/SimData_tr_for_1ch_A_tr90'
feats_path='/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/Joint_Modeling/Pre_processing/JT_TRIAL_FOLDER/tr_90'
p1 = Popen(['apply-cmvn', '--print-args=false', '--norm-vars=false', '--norm-means=false',
            '--utt2spk=ark:' +
            str(path) + '/' + '/utt2spk',
            'scp:' + str(path) + '/cmvn.scp',
            'scp:' + str(feats_path) + '/feats.scp', 'ark:-'],
            stdout=PIPE)
p2 = Popen(['splice-feats', '--print-args=false', '--left-context=0', '--right-context=0',
            'ark:-', 'ark:-'], stdin=p1.stdout, stdout=PIPE)
p1.stdout.close()
p3 = Popen(['add-deltas', '--delta-order=0', '--print-args=false',
            'ark:-', 'ark:-'], stdin=p2.stdout, stdout=PIPE)
#        p3 = Popen (yy=None, stdin=p2.stdout, stdout=PIPE) # no deltas in processing

p2.stdout.close()

#bp()
while True:
    #bp()


    uid, featMat_all = kaldiIO.readUtterance(p3.stdout)  # no deltas used
    outfile=str(feats_path) + str(uid) + '.npy'

    numpy.save(outfile, featMat_all)


p3.stdout.close()

bp()




   