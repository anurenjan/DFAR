Part 1: Getting data for training

1.run the preprocess.sh for getting the training data.json file.
2. Your folder structure should look like "data-Input_training_data_2_sec_gn_auto", and in the bash file specify the target folder name
3. The process basically has number of stages, which stage you want to run you may look into that. But if you wanted to get the data.json file directly run all the stage one after the another.
4. Codes can be modfied/improved as per your need, but this will give you general idea how things should be.
5. After running this code, copy paste the data.json where you are doing e2e experiment and do the training of asr.


Part 2: Getting data for decoding
