#!/bin/bash

#E2E ASR FOR SAMSUNG 150 HRS

. ./path_jt.sh || exit 1;
. ./cmd.sh || exit 1;

# general configuration
backend=pytorch
stage=1        # start from 0 if you need to start from data preparation
stop_stage=1
ngpu=1         # number of gpus ("0" uses cpu, otherwise use gpu)
debugmode=1
dumpdir=dump_FBANK_exp4_new   # directory to dump full features
N=0            # number of minibatches to be used (mainly for debugging). "0" uses all minibatches.
verbose=0      # verbose option
#resume=/home/rohitk/Workspace/E2E/espnet/egs/chime6/voices_1/exp/train_data_pytorch_train/results/snapshot.ep.26        # Resume the training from snapshot
resume=
foreground_snrs="20:10:15:5:0"
background_snrs="20:10:15:5:0"

# feature configuration
do_delta=false
lm_config=conf/lm.yaml
train_config=conf/train.yaml
decode_config=conf/decode.yaml

# rnnlm related
use_wordlm=true     # false means to train/use a character LM
lm_vocabsize=65000  # effective only for word LMs
lm_resume=          # specify a snapshot file to resume LM training
lmtag=              # tag for managing LMs


# decoding parameter
recog_model=model.loss.best # set a model to be used for decoding: 'model.acc.best' or 'model.loss.best'

# data #data will be mentioned in the wac.scp
data_corpus=

# exp tag
expdir="exp/exp7_joint" # tag for managing experiments.

. utils/parse_options.sh || exit 1;

# Set bash to 'debug' mode, it will exit on :
# -e 'error', -u 'undefined variable', -o ... 'error in pipeline', -x 'print commands',
set -e
set -u
set -o pipefail

lm_url=www.openslr.org/resources/11
train_data=train_clean_100_reverb
eval_data=Evaluation_Data_wpe


# NOW WE SPECIFY THE TRAINING DATA, AND SPLIT IT IN TRAIN AND DEV


train_set=train_data
#train_set_wsj=train_wsj_clean
#train_set_rvb=REVERB_tr_cut
dev_real=data-Input_raw_data/REVERB_Real_dt
dev_simu=data-Input_raw_data/REVERB_dt_simu
#dev_multi=REVERB_dt_multi
eval_real=data-Input_raw_data/REVERB_Real_et
eval_simu=data-Input_raw_data/REVERB_et_simu

eval_temp=JT_TRIAL_FOLDER/tr_90



# CREATE THE DICTIONARY FOR DATA TRAINING
#dict=data/lang_1char/${train_set}_units.txt
dict=data/lang_1char/${train_set}_units.txt
echo "dictionary: ${dict}"
nlsyms=data/lang_1char/non_lang_syms.txt


##########################################################################################################################





# decoding parameter
recog_model=model.acc.best # set a model to be used for decoding: 'model.acc.best' or 'model.loss.best'



if [ -z ${lmtag} ]; then
    lmtag=$(basename ${lm_config%.*})
    if [ ${use_wordlm} = true ]; then
        lmtag=${lmtag}_word${lm_vocabsize}
    fi
fi

lmexpname=train_rnnlm_${backend}_${lmtag}
lmexpdir=exp/${lmexpname}

###############################################################################################################################################
if [ ${stage} -le 1 ] && [ ${stop_stage} -ge 1 ]; then
    echo "stage 7: Decoding"
    nj=5
    pids=() # initialize pids
    for rtask in ${dev_real} ${dev_simu} ${eval_real} ${eval_simu}; do
    #for rtask in ${train_dev}; do
    (  
	if [ ${use_wordlm} = true ]; then
        decode_dir=decode_${rtask}_$(basename ${decode_config%.*})_${lmtag}
	if [ ${use_wordlm} = true ]; then
        recog_opts="--word-rnnlm ${lmexpdir}/rnnlm.model.best"
        else
        recog_opts="--rnnlm ${lmexpdir}/rnnlm.model.best"
        fi
        else
        decode_dir=decode_${rtask}_$(basename ${decode_config%.*})
        recog_opts=""
        fi 
        feat_recog_dir=${rtask}

        mkdir -p ${expdir}/${decode_dir}/log

        # split data
        /home/rohitk/Workspace/E2E/espnet/utils/splitjson.py --parts ${nj} ${feat_recog_dir}/data.json

        for JOBS in `seq 1 $nj`; do
        qsub -q med.q -l hostname=compute-0-[2-4] -V -cwd -e ${expdir}/${decode_dir}/log/decode.${JOBS}.log -o ${expdir}/${decode_dir}/log/decode.${JOBS}.log -S /bin/bash asr_recog_code.sh ${feat_recog_dir}/split${nj}utt/data.${JOBS}.json ${expdir}/${decode_dir}/data.${JOBS}.json ${expdir} ${lmexpdir}/rnnlm.model.best
        sleep 3s
        done

    )
    done

    echo "Finished submitting decoding jobs"
fi

#exit



if [ ${stage} -le 2 ] && [ ${stop_stage} -ge 2 ]; then

. ./path.sh || exit 1;
    echo "stage 8: Decoding Results"
    nj=1

    pids=() # initialize pids
    for rtask in ${dev_real} ${dev_simu} ${eval_real} ${eval_simu}; do
    #for rtask in ${train_dev}; do
    (
        

        decode_dir=decode_${rtask}_$(basename ${decode_config%.*})_${lmtag}
        


        ngpu=0

        score_sclite.sh --wer true ${expdir}/${decode_dir} ${dict}

    )
    done
fi
