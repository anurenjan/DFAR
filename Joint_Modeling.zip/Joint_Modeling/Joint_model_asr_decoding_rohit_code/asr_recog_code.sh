#!/bin/bash
# This is the bash code which will be called upon while decoding.
# In this most of the times you have to just have to change model

. ./cmd.sh
. ./path.sh

decode_config=conf/decode.yaml
ngpu=1

data_file=$1

result_l=$2


model_path=$3


model=$model_path/results/model.acc.best
rnnlm_path=$4

 
/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/JOINT_TRN/espnet/bin/asr_recog.py --config $decode_config --ngpu 0 --backend pytorch --debugmode 1 --recog-json $data_file --result-label $result_l --model $model --word-rnnlm $rnnlm_path
