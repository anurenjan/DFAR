#!/bin/bash

. ./cmd.sh
. ./path_jt.sh

decode_config=conf/decode.yaml
ngpu=1

data_file=JT_TRIAL_FOLDER/cv_10/data.json

result_l=exp/decode_trial/data.json

model=exp/results/model.acc.best



ab=`nvidia-smi --query-gpu=index,memory.used --format=csv`
echo $ab
zero=`echo $ab | awk '{print $5}'`
one=`echo $ab | awk '{print $8}'`
gpu=0
if [ $zero -le  $one ] ;then
gpu=0
else
gpu=1
fi
echo "using gpu ${gpu}"


CUDA_VISIBLE_DEVICES=${gpu} python /data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/JOINT_TRN/espnet/bin/asr_recog.py --config conf/decode.yaml --ngpu 0 --backend pytorch --debugmode 1 --recog-json $data_file --result-label $result_l --model $model --word-rnnlm exp/train_rnnlm_pytorch_lm_word65000/rnnlm.model.best
