from subprocess import Popen, PIPE, check_output
import tempfile
import kaldi_io


#import scipy.io as sio
from pdb import set_trace as bp

import csv
import numpy

file = '/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/ASR/FDLP_enhmt_ASR_envelope_only_FBANK_trial_2/temp/REVERB_tr_cut/feats.scp'


bp()

for key,mat in kaldi_io.read_mat_scp(file):
     abc = mat
     numpy.save(str(key)+'.npy', mat)

