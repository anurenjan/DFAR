#!/bin/bash

. ./cmd.sh
. ./path_jt.sh

python circonv_mod_trial.py 

