#!/bin/bash

. ./cmd.sh
. ./path_jt.sh

python joint_model_train.py --config conf/train.yaml --ngpu 1 --backend pytorch --outdir exp/train_data_pytorch_REVERB_FBANK_CLN_WSJ_BR_NO_SHUFFLE_WITH_SP_PT3_MULTI_exp7/results --tensorboard-dir tensorboard/train_data_pytorch_REVERB_FDLP_CLN_WSJ_BR_DT_MULTI_WITH_SP_PT3_exp7 --debugmode 1 --dict data/lang_1char/train_data_units.txt --debugdir exp/train_data_pytorch_REVERB_FBANK_CLN_WSJ_BR_NO_SHUFFLE_WITH_SP_PT3_MULTI_exp7 --minibatches 0 --verbose 0 --resume --train-json JT_TRIAL_FOLDER/tr_90/data.json --valid-json JT_TRIAL_FOLDER/cv_10/data.json

