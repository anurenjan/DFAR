from sre_constants import RANGE
import numpy as np
import torch
import torch.nn.functional as F
#import torch.fft

import os
import sys 
from pdb import set_trace as bp  #################added break point
bp()

A_np = np.expand_dims(np.arange(0, 500, 1, dtype=float),axis=0)
B_np = np.expand_dims(np.arange(0, 15, 1, dtype=float),axis=0)

N = 500

A_torch = torch.from_numpy(A_np)
B_torch = torch.from_numpy(B_np)

A_torch_pad = F.pad(input=A_torch, pad=(0, N-A_torch.shape[1],0,1), mode='constant', value=0)
B_torch_pad = F.pad(input=B_torch, pad=(0, N-B_torch.shape[1],0,1), mode='constant', value=0)

#C_torch = torch.zeros((1,N))


'''for n in range(N):

    for m in range(N):
        
        temp = A_torch_pad[0,m]*B_torch_pad[0,torch.remainder(torch.tensor(n-m), N)]
        C_torch[0,n] = C_torch[0,n] + temp
        '''

bp()

A_torch_pad_fft = torch.view_as_complex(torch.fft(A_torch_pad.T,1))
B_torch_pad_fft = torch.view_as_complex(torch.fft(B_torch_pad.T,1))

C_torch_temp_fft = torch.view_as_real(torch.mul(A_torch_pad_fft, B_torch_pad_fft))

C_torch_temp = torch.ifft(C_torch_temp_fft,1)

C_np = (np.fft.ifft(np.multiply(np.fft.fft(A_np,N), np.fft.fft(B_np,N)))).real


abc = C_torch_temp - C_np
torch.max(torch.max(abc))
torch.min(torch.min(abc))

#C_torch_temp = (torch.fft.ifft(torch.mul(torch.fft.fft(A_torch,N), torch.fft.fft(B_torch,N)))).real




def circonv_mod(A,B,N):

    bp()
    
    if A.shape[0] != 1:
        A = A.T
    if B.shape[0] != 1:
        B = B.T
    

    A_pad = F.pad(input=A, pad=(0, N-A_torch.shape[1],0,1), mode='constant', value=0)
    B_pad = F.pad(input=B, pad=(0, N-B_torch.shape[1],0,1), mode='constant', value=0)

    A_pad_fft = torch.view_as_complex(torch.fft(A_pad.T,1))
    B_pad_fft = torch.view_as_complex(torch.fft(B_pad.T,1))

    C_fft = torch.view_as_real(torch.mul(A_pad_fft, B_pad_fft))

    C = torch.ifft(C_fft,1)



    return C[:,0].T