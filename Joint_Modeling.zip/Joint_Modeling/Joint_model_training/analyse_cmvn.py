from subprocess import Popen, PIPE, check_output
import tempfile
import kaldiIO

import scipy.io as sio
from pdb import set_trace as bp

import csv
import numpy

bp()

reader = csv.reader(open("cmvn.txt", "rt", encoding="utf-8"), delimiter=" ")
x = list(reader)
result = numpy.array(x).astype("float")


mean = result[0][:-1]/result[0][-1]
var = result[1][:-1]/result[0][-1] - mean * mean
std_floor=1.0e-20
std = numpy.maximum(numpy.sqrt(var), std_floor)
bias = -mean
scale = 1/std

x[0]= bias
x[1]=scale

numpy.save('cmvn.npy', numpy.array(x))
