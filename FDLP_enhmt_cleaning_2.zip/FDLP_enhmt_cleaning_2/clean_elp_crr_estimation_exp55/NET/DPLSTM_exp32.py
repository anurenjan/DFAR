import torch
import torch.nn as nn
from pdb import set_trace as bp  #################added break point accessor####################

################### ''' large kernel = (10,3) with 32 filters with LSTM''' ######################
class Net (nn.Module):
    def __init__(self):
        super(Net,self).__init__()
        self.lstm_t1 = nn.LSTM(128, 1024 , batch_first=True) 
        self.lstm_t2 = nn.LSTM(1024, 1024 , batch_first=True)
        self.lstm_t3 = nn.LSTM(1024, 1024 , batch_first=True)
        self.lstm_t4 = nn.LSTM(1024, 128 , batch_first=True) 

        self.lstm_f1 = nn.LSTM(250, 1024 , batch_first=True) 
        self.lstm_f2 = nn.LSTM(1024, 1024 , batch_first=True)
        self.lstm_f3 = nn.LSTM(1024, 1024 , batch_first=True)
        self.lstm_f4 = nn.LSTM(1024, 250 , batch_first=True)

        self.lstm_bi1 = nn.LSTM(256, 1024 , batch_first=True, bidirectional=True) 
        self.lstm_bi2 = nn.LSTM(2048, 1024 , batch_first=True, bidirectional=True)
        self.lstm_bi3 = nn.LSTM(2048, 1024 , batch_first=True, bidirectional=True)
        self.lstm_bi4 = nn.LSTM(2048, 1024 , batch_first=True, bidirectional=True)
        self.lstm_bi5 = nn.LSTM(2048, 64 , batch_first=True, bidirectional=True)



    def forward(self, x):
        x_t=x
        x_f=x.permute(0, 2, 1)
        #bp()
        x_t,_ = self.lstm_t1(x_t)
        x_t,_ = self.lstm_t2(x_t) 
        x_t,_ = self.lstm_t3(x_t)  
        x_t,_ = self.lstm_t4(x_t)
        x_f,_ = self.lstm_f1(x_f)
        x_f,_ = self.lstm_f2(x_f) 
        x_f,_ = self.lstm_f3(x_f)  
        x_f,_ = self.lstm_f4(x_f) 
        x_tf = torch.cat((x_t, x_f.permute(0, 2, 1)), 2)
        #bp()
        x_tf,_ = self.lstm_bi1(x_tf)
        x_tf,_ = self.lstm_bi2(x_tf)
        x_tf,_ = self.lstm_bi3(x_tf) 
        x_tf,_ = self.lstm_bi4(x_tf)  
        x_tf_final,_ = self.lstm_bi5(x_tf)
        #bp()
       
        return x_tf_final

 
         
