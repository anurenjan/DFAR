#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov  4 14:41:28 2019

@author: user
"""

import torch
import numpy 
import sys
from NET.DPLSTM_exp32 import Net
from pdb import set_trace as bp  #################added break point accessor####################
from fdlp_env_comp_100hz_factor_40 import fdlp_env_comp_100hz_factor_40
from read_HTK import HTKFeat_read, HTKFeat_write
from QMF_7_synthesis_W_bark_mod_64_band import QMF_7_synthesis_W_bark_mod_64_band


def forward_pass(data_original, exp_envelope, exp_carrier, model_name_envelope, model_name_carrier, in_channel=1, inputFeatDim=128):
  """Does forward pass, exponential and short term integration on the input 
    Returns the cepstra of the data"""   

  data_original_env = numpy.log(data_original[:,0:64])

  print("########### Normalizing ###########")

  data_original_cmvn = (data_original_env - data_original_env.mean(axis=0)) / data_original_env.std(axis=0)

  data_feat_unpack = numpy.concatenate(( data_original_cmvn, data_original[:,64:128]),axis=1)
  ##bp()
  len_in = data_feat_unpack.shape[0]
  f=data_feat_unpack.shape[0]//250
  trim=250*f 
  ##bp()
  sr = 16000
  R = 24*sr//1000
  ##bp()

  untrim = numpy.zeros((250-data_feat_unpack.shape[0]+trim,128)) # (trim - len_in) == add_sample in matlab
  data_feat_unpack = numpy.concatenate((data_feat_unpack,untrim),axis=0)
  featListFirst =data_feat_unpack.reshape(1,in_channel,data_feat_unpack.shape[0],inputFeatDim)
  featListFinal_tp=numpy.empty((1,1,250,128))
   	
  for x in range(f):
     temp1=featListFinal_tp
     featListFinal_tp=numpy.concatenate((temp1,featListFirst[:,:,((x)*250):((x+1)*250),:]),axis=0)
  cepstra_in=featListFinal_tp[1:,:,:,:]
  cepstra_in= cepstra_in.astype(numpy.float32)

  ##bp()


  print("########### Loading the trained envelope-model ##########")

  model_envelope = exp_envelope + '/' + model_name_envelope
  net_envelope= Net()
  net_envelope.eval()
  net_envelope.load_state_dict(torch.load(model_envelope,map_location=lambda storage, loc: storage))

#   print("########### Loading the trained carrier-model ##########")

#   model_carrier = exp_carrier + '/' + model_name_carrier
#   net_carrier= Net()
#   net_carrier.eval()
#   net_carrier.load_state_dict(torch.load(model_carrier,map_location=lambda storage, loc: storage))
  
  print("########### Forward Pass envelope carrier model ###########")

  #bp()

  cepstraTorch = torch.from_numpy(cepstra_in[:,:,:,:])
  cepstraTorch = torch.squeeze(cepstraTorch,1)
  output_envelope = net_envelope(cepstraTorch)
  output_envelope = output_envelope.detach().numpy()
  ##bp()
  output_envelope = output_envelope.reshape(-1,1,250,128)
  
  #diff = outputs1 outputs2
  output_envelope = output_envelope + cepstra_in[:,:,:,0:128]

  output_envelope[:,:,:,0:48] = cepstra_in[:,:,:,0:48]
  output_envelope[:,:,:,0+64:48+64] = cepstra_in[:,:,:,0+64:48+64]

  ##bp()
  print("########### De-normalizing ###########")
  outExp = (output_envelope[:,:,:,0:64] * data_original_env.std(axis=0)) + data_original_env.mean(axis=0)



  ##bp()

  print("########### adding exponential ###########")
  outExp = numpy.exp(outExp)


#   print("########### Forward Pass carrier ###########")

#   cepstraTorch_carrier = torch.from_numpy(cepstra_in[:,:,:,64:128])
#   output_carrier = net_carrier(cepstraTorch_carrier)
#   output_carrier = output_carrier.detach().numpy()
#   ##bp()
#   output_carrier = output_carrier.reshape(-1,1,250,64)
  
#   #diff = outputs1 outputs2
#   output_carrier = output_carrier + cepstra_in[:,:,:,64:128]
#   print("########### adding exponential ###########")
#   outExp_carrier = numpy.exp(output_carrier)

  ##bp()
  
  #Signal_enhanced = numpy.multiply(output_envelope, output_carrier)

  #Signal_enhanced = numpy.multiply(numpy.exp(cepstra_in[:,:,:,0:64]), numpy.exp(cepstra_in[:,:,:,64:128]))

  ##bp()
  
  Signal_enhanced = numpy.multiply(outExp, output_envelope[:,:,:,64:128])




  ##bp()
  print("########### short term integration ###########")
  #cepstra_envelope = []
  if f == 0:
      data = QMF_7_synthesis_W_bark_mod_64_band(Signal_enhanced[f,0,:,:])
      Signal_total = data.T
  else :     
      for i in range(f):

       data = Signal_enhanced[i,0,:,:]
       Intout = (QMF_7_synthesis_W_bark_mod_64_band(data)).T
       ##bp()
       if i == 0:
          Signal_total = Intout
       else :
          ovr_region = Signal_total[-R:] + Intout[0:R]
          ##bp()
          Signal_total = numpy.concatenate((Signal_total[0:-R], ovr_region, Intout[R:]),axis=0)  
  #cepstra_envelope = numpy.asarray(cepstra_envelope)     
  ##bp()

  Signal_total=Signal_total/numpy.max(numpy.abs(Signal_total))


  

  #
  ##bp()
  return Signal_total


def open(f, mode=None, veclen=128):
    """Open an HTK format feature file for reading or writing.
    The mode parameter is 'rb' (reading) or 'wb' (writing)."""
    
    if mode is None:
        if hasattr(f, 'mode'):
            mode = f.mode
        else:
            mode = 'rb'
    if mode in ('r', 'rb'):
        
        return HTKFeat_read(f) # veclen is ignored since it's in the file
    elif mode in ('w', 'wb'):
        return HTKFeat_write(f, veclen)
    else:
        raise Exception( "mode must be 'r', 'rb', 'w', or 'wb'")

#data_in = open('ones.fea', 'rb') 
#data_original = data_in.getall()
#data_original = data_original.T
##bp()
#Intout = fdlp_env_comp_100hz_factor_40(data_original,250, 128)
#write_htk( 'python_ones_int.fea' , Intout , 100000 , 8267 )
#data_int = open('python_ones_int.fea', 'rb') 
#data_integrate = data_int.getall()
#print("################################# MATLAB OUTPUT ##############################################")
#data_mat = open('ones_int.fea', 'rb') 
#data_matint = data_mat.getall()
