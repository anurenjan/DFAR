import numpy 
import os
import sys 
from pdb import set_trace as bp  #################added break point
import scipy.io
from scipy import signal
from circonv_mod import circonv_mod
from QMF_7_synthesis_W_bark_mod_64_band import QMF_7_synthesis_W_bark_mod_64_band

X = numpy.repeat(numpy.expand_dims(numpy.linspace(1, 250, num=250), axis=1), 64, axis=1)

B = QMF_7_synthesis_W_bark_mod_64_band(X)
bp()
    

