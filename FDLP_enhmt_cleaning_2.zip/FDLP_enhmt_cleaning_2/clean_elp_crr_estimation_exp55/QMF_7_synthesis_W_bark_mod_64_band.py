import numpy 
import os
import sys 
from pdb import set_trace as bp  #################added break point
import scipy.io
from scipy import signal
from circonv_mod import circonv_mod


def QMF_7_synthesis_W_bark_mod_64_band(X):

    #X = numpy.repeat(numpy.expand_dims(numpy.linspace(1, 250, num=250), axis=1), 64, axis=1)
    matfilt = scipy.io.loadmat('/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning/clean_elp_estimation/mfilters2.mat')

    # First level
    Y_1=numpy.zeros((len(X[:,:])*2,64))

    for i in range(64):
        Y_1[:,i:i+1] = numpy.zeros((len(X[:,i])*2,1))
        Y_1[::2,i:i+1] = X[:,i:i+1]


    N = 99
    # Second level
    F_1 = matfilt['GlpF6']
    F_2 = matfilt['GhpF6']
    N6 = 13
    k = numpy.arange(0,64,2)


    #bp()


    Y_2=numpy.zeros((len(Y_1[:,:])*2,32))


    for i in range(32):
        Hlp= numpy.roll(circonv_mod(Y_1[:,k[i]:k[i]+1], F_1, Y_1.shape[0]) +circonv_mod(Y_1[:,k[i]+1:k[i]+2], F_2, Y_1.shape[0]),-N6)
        Y_2[::2,i:i+1] = Hlp.T
        del Hlp

    #bp()

    # # Third level 
    F_1 = matfilt['GlpF5']
    F_2 = matfilt['GhpF5']
    N5 = 17
    k = numpy.arange(0,32,2)

    Y_3=numpy.zeros((len(Y_2[:,:])*2,16))

    for i in range(16):
        Hlp= numpy.roll(circonv_mod(Y_2[:,k[i]:k[i]+1], F_1, Y_2.shape[0]) +circonv_mod(Y_2[:,k[i]+1:k[i]+2], F_2, Y_2.shape[0]),-N5)
        Y_3[::2,i:i+1] = Hlp.T
        del Hlp

    #bp()
    # # Fourth level 

    del F_1
    del F_2
    F_1 = matfilt['GlpF4']
    F_2 = matfilt['GhpF4']
    N4 = 25
    k = numpy.arange(0,16,2)

    Y_4=numpy.zeros((len(Y_3[:,:])*2,8))

    for i in range(8):
        Hlp= numpy.roll(circonv_mod(Y_3[:,k[i]:k[i]+1], F_1, Y_3.shape[0]) +circonv_mod(Y_3[:,k[i]+1:k[i]+2], F_2, Y_3.shape[0]),-N4)
        Y_4[::2,i:i+1] = Hlp.T
        del Hlp


    # # Fifth level 

    del F_1
    del F_2
    F_1 = matfilt['GlpF3']
    F_2 = matfilt['GhpF3']
    N3 = 51
    k = numpy.arange(0,8,2)

    Y_5=numpy.zeros((len(Y_4[:,:])*2,4))

    for i in range(4):
        Hlp= numpy.roll(circonv_mod(Y_4[:,k[i]:k[i]+1], F_1, Y_4.shape[0]) +circonv_mod(Y_4[:,k[i]+1:k[i]+2], F_2, Y_4.shape[0]),-N3)
        Y_5[::2,i:i+1] = Hlp.T
        del Hlp


    matfilt = scipy.io.loadmat('/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning/clean_elp_estimation/mfilters.mat')

    # # Sixth level 

    del F_1
    del F_2
    F_1 = matfilt['GlpF']
    F_2 = matfilt['GhpF']
    N2 = 99
    k = numpy.arange(0,4,2)

    Y_6=numpy.zeros((len(Y_5[:,:])*2,2))

    for i in range(2):
        #bp()
        Hlp= numpy.roll(circonv_mod(Y_5[:,k[i]:k[i]+1], F_1, Y_5.shape[0]) +circonv_mod(Y_5[:,k[i]+1:k[i]+2], F_2, Y_5.shape[0]),-N2)
        Y_6[::2,i:i+1] = Hlp.T
        del Hlp

    #bp()

    del F_1
    del F_2
    F_1 = matfilt['GlpF']
    F_2 = matfilt['GhpF']
    N2 = 99
    k = numpy.arange(0,2,2)

    Y_7= numpy.roll(circonv_mod(Y_6[:,0:1], F_1, Y_6.shape[0]) +circonv_mod(Y_6[:,1:2], F_2, Y_6.shape[0]),-N2)

    return Y_7
