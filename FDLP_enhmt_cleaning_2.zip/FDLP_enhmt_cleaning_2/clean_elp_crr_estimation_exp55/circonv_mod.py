import numpy as np
import os
import sys 
from pdb import set_trace as bp  #################added break point
#bp()
def circonv_mod(A,B,N):
    
    if A.shape[0] != 1:
        A = A.T
    if B.shape[0] != 1:
        B = B.T


    C = (np.fft.ifft(np.multiply(np.fft.fft(A,N), np.fft.fft(B,N)))).real

    return C