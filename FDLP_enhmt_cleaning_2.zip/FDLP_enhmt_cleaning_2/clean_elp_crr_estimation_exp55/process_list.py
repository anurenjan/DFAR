import numpy 
import os
import sys 
from pdb import set_trace as bp  #################added break point
from scipy.io import wavfile
from test_env_estmation import extract_feats_clean


exp_envelope        = "/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_training_2/exp/torch_FDLP_ENHMT_exp55"
model_name_envelope  = "dnn_nnet_64_8.model"

exp_carrier        = "/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_training_2/exp/torch_FDLP_ENHMT_exp55"
model_name_carrier  = "dnn_nnet_64_8.model"
 
inList       = sys.argv[1]

I = 1
f = open(inList, "r")
for x in f:
  print(x) 
  x = x.rstrip('\n')
  xa = x.split(' ')
  xaa = xa[0]
  xab = xa[1]
  print('Processing ' + str(I) + 'th file...')
  extract_feats_clean(xaa, xab, exp_envelope, exp_carrier, model_name_envelope, model_name_carrier)
  I += 1



