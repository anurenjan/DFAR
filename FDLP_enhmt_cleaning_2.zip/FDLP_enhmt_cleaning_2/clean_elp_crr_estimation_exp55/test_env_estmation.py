import numpy
import scipy.io 
from fdlp_env_comp_100hz_factor_40 import fdlp_env_comp_100hz_factor_40
from read_HTK import HTKFeat_read, HTKFeat_write
from pdb import set_trace as bp  #################added break point 
from forward_pass_cepstra import forward_pass
from write_HTK import write_htk
import soundfile as sf


in_channel = 1 
inputFeatDim = 128

def open(f, mode=None, veclen=128):
    """Open an HTK format feature file for reading or writing.
    The mode parameter is 'rb' (reading) or 'wb' (writing)."""
    
    if mode is None:
        if hasattr(f, 'mode'):
            mode = f.mode
        else:
            mode = 'rb'
    if mode in ('r', 'rb'):
        
        return HTKFeat_read(f) # veclen is ignored since it's in the file
    elif mode in ('w', 'wb'):
        return HTKFeat_write(f, veclen)
    else:
        raise Exception( "mode must be 'r', 'rb', 'w', or 'wb'")

def extract_feats_clean(data, data_out, exp_envelope, exp_carrier, model_name_envelope, model_name_carrier, in_channel = 1,inputFeatDim = 128):
  data_in = open(data, 'rb') 
  data_original_no_cmvn = data_in.getall()
  #bp()
  #data_original = (data_original_no_cmvn - data_original_no_cmvn.mean(axis=0)) / data_original_no_cmvn.std(axis=0)

  clean_data = forward_pass(data_original_no_cmvn, exp_envelope, exp_carrier, model_name_envelope, model_name_carrier, in_channel, inputFeatDim )
  #bp()
  clean_data = clean_data.astype("float64")
  sf.write(data_out, clean_data, 16000)
  #bp()
  print("########### cleaned the data ###########")
 



