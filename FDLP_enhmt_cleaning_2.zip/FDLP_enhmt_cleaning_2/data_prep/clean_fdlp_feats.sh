echo "generate feats init"

feaDir=$1
list=$2
process_list_path=$3

cnt=`cat $list | wc -l | awk '{print int ($1 / 20) +1 }'`
mkdir -p ${feaDir} || exit 1;
split -l $cnt $list ${feaDir}/segments_
echo "$cnt"

for file in `ls ${feaDir}/segments_*`
do
  echo $file
  python $process_list_path/process_list.py $file
done
