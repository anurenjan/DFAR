featdir=$1
utils/subset_data_dir_tr_cv.sh ${featdir} ${featdir}_tr90 ${featdir}_cv10

