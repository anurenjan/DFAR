#pwdr=/home/data2/multiChannel/ANURENJAN/REVERB/ENV_estimation/Env_wpe_gev_BF_estimation_python
pwdr=$1
new_dir=$2
hcopybin=$3
inputfeat_dir_rev=$4
process_list_path=$5

for y in $pwdr/* ; do

   echo $y
   
   rm -rf $y/newfea
   rm -rf $y/splits
   a=1
   featdir=$y/newfea
   L=`wc -l <$y/fea.scp`

   N=$((L*a))
   echo "N is = $N"

   bash data_prep/fdlp_cleaning.sh $y $new_dir $hcopybin $inputfeat_dir_rev $process_list_path

		
   cnter=`ls $featdir/*.wav | wc -l | awk '{print $1}'`
   echo "center is = $cnter"


   while [ "$cnter" -lt "$N" ] ; do

     sleep 15s
     echo "waiting for $cnter to be equal to $N"
     cnter=`ls $featdir/*.wav | wc -l | awk '{print $1}'`
   done		
   echo "Feats  for $y is Done"
 done


echo "Feats  for all directories Done"

