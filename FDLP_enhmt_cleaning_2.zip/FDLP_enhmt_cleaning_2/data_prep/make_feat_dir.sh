rvb_dir=$1
pwdr=$2   



     
mkdir -p $pwdr


scp -r $rvb_dir/* $pwdr

     


