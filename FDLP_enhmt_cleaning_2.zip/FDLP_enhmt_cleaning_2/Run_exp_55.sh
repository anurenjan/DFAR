#!/bin/bash
############################## Set The Stage ############################## 
set -e
stage=3
nj=25
############################## Run Cmd.sh and Path.sh ##############################
. ./cmd.sh
. ./path.sh

############################## Set the Directory names ############################## 
sdir=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning_2
pwdr=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning_2/Input_raw_data
pwd=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning_2/

hcopybin=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning_2/data_prep/generate_fdlp_feats_mc.sh
hcopybin_cleaning=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning_2/data_prep/clean_fdlp_feats.sh
matlab_path=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning_2/FDLP_QMF_64_band_env_carr

process_list_path=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning_2/clean_elp_crr_estimation_exp55

inputfeat_dir="DLSTM_exp55"
inputfeat_dir_rev=Input_raw_data

dir=/data2/multiChannel/ANURENJAN/SPEECH_ENHANCEMENT/FDLP_based_enhmt/REVERB/FDLP_enhmt_cleaning_2/


rvb_dir=/data2/multiChannel/ANURENJAN/REVERB_E2E/REVERB_DATA_MASTER

############################## Make Directories ############################## 

if [ $stage -le 1 ] ; then

bash data_prep/make_feat_dir.sh $rvb_dir $pwdr
echo "############################## Feat Directory is ready ############################## "
fi


#exit

if [ $stage -le 2 ] ; then
echo "Splitting the jobs to generate the features from matlab"
bash data_prep/step1_fdlp_gen.sh $pwdr $hcopybin $matlab_path $nj
fi

#exit

if [ $stage -le 3 ] ; then
echo "Generation fea.scp from the raw features extracted"
bash data_prep/make_fea_scp.sh $pwdr $pwd $inputfeat_dir $inputfeat_dir_rev
fi

#exit

if [ $stage -le 4 ] ; then
echo "Clean the features and extracting new features"
############ "Change the model path in process_list.py, copy the Net into the clean_elp_estimation_carrier/NET folder and import this new Net in the forward_pass_cepstra.py before running this" #######################
bash data_prep/step1_fdlp_cleaning.sh $pwd/$inputfeat_dir $inputfeat_dir $hcopybin_cleaning $inputfeat_dir_rev $process_list_path

echo "Done"
fi



exit


false&&
{
if [ $stage -le 5 ] ; then
echo "Convert to kaldi Reverb data"
bash data_prep/Convert_to_kaldi.sh $inputfeat_dir $dir  
fi

#if [ $stage -le 6 ] ; then
#echo "Create subset for the training and cross validation"
#bash data_prep/subset.sh $subset_dir
#fi
}



